/* A simple C program for testing our Parenthesis Validation Checker */

#include<stdio.h>


int main(){
    int a = 2;
    int b = 3;
    scanf("%d",a);
    scanf("%d",b);
    printf("a + b = %d\n", a + b);
    return (0);
}