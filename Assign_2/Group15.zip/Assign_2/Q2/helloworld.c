/* A simple C program for testing our Parenthesis Validation Checker */

#include<stdio.h>


int main(){
    int a = 2;
    int b = 3;
    printf("a + b = %d\n", a + b);
    return (0);
}